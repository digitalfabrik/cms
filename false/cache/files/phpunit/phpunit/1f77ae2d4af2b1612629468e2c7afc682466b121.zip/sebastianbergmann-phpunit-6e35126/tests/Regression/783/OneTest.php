<?php
/**
 * @group foo
 */
class OneTest extends PHPUnit_Framework_TestCase
{
    public function testSomething()
    {
    }
}
