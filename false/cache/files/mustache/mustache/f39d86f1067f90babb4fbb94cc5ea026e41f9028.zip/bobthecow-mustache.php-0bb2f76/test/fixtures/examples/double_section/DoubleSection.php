<?php

class DoubleSection
{
    public function t()
    {
        return true;
    }

    public $two = 'second';
}
