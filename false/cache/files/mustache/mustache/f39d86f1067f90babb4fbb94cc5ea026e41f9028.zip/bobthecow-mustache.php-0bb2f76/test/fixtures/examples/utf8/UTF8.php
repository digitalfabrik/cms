<?php

class UTF8
{
    public $test = '中文又来啦';
}
