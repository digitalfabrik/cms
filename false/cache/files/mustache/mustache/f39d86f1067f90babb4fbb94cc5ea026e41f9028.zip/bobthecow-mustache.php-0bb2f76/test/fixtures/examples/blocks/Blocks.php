<?php

class Blocks
{
    public $items = array(1, 2, 3);
}
